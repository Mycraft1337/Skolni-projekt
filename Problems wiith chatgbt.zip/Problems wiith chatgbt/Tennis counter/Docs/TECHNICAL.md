# Architecture

Draft populated from detected project files. Verify the findings and complete the blank fields; compliance is not certified automatically.

```json
{
  "architecture_design_rationale" : "",
  "declared_version" : "",
  "detected_stack" : "Web",
  "entry_points" : [
    "Tennis counter/index.html"
  ],
  "extensions" : {
    "css" : 1,
    "html" : 1,
    "js" : 1,
    "md" : 2
  },
  "npm_scripts" : {

  },
  "owner" : "",
  "project" : "Tennis counter",
  "security_review" : "",
  "source_file_count_bounded" : 5,
  "source_inventory_sample" : [
    "Tennis counter/app.js",
    "Tennis counter/index.html",
    "Tennis counter/README.md",
    "Tennis counter/START-HERE.md",
    "Tennis counter/styles.css"
  ]
}
```
