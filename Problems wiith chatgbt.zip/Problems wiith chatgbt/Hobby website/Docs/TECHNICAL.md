# Architecture

Draft populated from detected project files. Verify the findings and complete the blank fields; compliance is not certified automatically.

```json
{
  "architecture_design_rationale" : "",
  "declared_version" : "",
  "detected_stack" : "Web",
  "entry_points" : [
    "Hobby website/index.html"
  ],
  "extensions" : {
    "css" : 1,
    "html" : 1,
    "js" : 1,
    "md" : 2
  },
  "npm_scripts" : {

  },
  "owner" : "",
  "project" : "Hobby website",
  "security_review" : "",
  "source_file_count_bounded" : 5,
  "source_inventory_sample" : [
    "Hobby website/app.js",
    "Hobby website/index.html",
    "Hobby website/README.md",
    "Hobby website/START-HERE.md",
    "Hobby website/styles.css"
  ]
}
```
