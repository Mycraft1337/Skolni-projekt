# Security

Describe architecture, interfaces, dependencies and diagrams.
