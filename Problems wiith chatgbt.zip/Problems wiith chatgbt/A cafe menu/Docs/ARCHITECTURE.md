# Architecture

Describe architecture, interfaces, dependencies and diagrams.
