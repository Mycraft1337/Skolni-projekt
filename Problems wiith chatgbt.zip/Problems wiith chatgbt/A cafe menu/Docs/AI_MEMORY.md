# Project memory

Record decisions, constraints and next steps. Chat reads this file; updates require review.
