# Architecture

Draft populated from detected project files. Verify the findings and complete the blank fields; compliance is not certified automatically.

```json
{
  "architecture_design_rationale" : "",
  "declared_version" : "",
  "detected_stack" : "Web",
  "entry_points" : [
    "A cafe menu/index.html"
  ],
  "extensions" : {
    "css" : 1,
    "html" : 1,
    "js" : 1,
    "md" : 2
  },
  "npm_scripts" : {

  },
  "owner" : "",
  "project" : "A cafe menu",
  "security_review" : "",
  "source_file_count_bounded" : 5,
  "source_inventory_sample" : [
    "A cafe menu/app.js",
    "A cafe menu/index.html",
    "A cafe menu/README.md",
    "A cafe menu/START-HERE.md",
    "A cafe menu/styles.css"
  ]
}
```
