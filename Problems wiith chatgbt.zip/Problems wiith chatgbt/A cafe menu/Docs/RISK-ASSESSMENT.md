# Risk assessment

Describe architecture, interfaces, dependencies and diagrams.
